# kod-paylasim-sitesi
Merhaba altyapı bot list sitesiydi fakat ben(Yusuf) ve Ahmet el ele tutup kod paylaşıma çevirdik kod paylaşım sunucuları için altyapıda hiçbir hata yoktur test edebilirsiniz.
Önizleme https://devtr.me
